START HERE

You chose a simple Windows installer. This package now includes the original plugin source plus scripts to build and package a Windows x64 VST3 installer.

Important: a ready-to-install Setup.exe is NOT included yet. Building must happen on Windows with Visual Studio, CMake, JUCE, and Inno Setup installed. See INSTALLER_STATUS.txt for exact steps.

The current code is a basic prototype (filter/compression controls), not the finished one-click AI producer described in the long-term plan.
