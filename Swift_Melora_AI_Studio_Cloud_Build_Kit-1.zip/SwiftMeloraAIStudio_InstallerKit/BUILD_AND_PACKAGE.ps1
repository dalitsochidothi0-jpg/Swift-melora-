$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BuildDir = Join-Path $ProjectDir 'build'

Write-Host 'Swift Melora AI Studio - Build and Package' -ForegroundColor Cyan
Write-Host 'This script builds the current prototype. It does not add the planned AI features.'

$cmake = Get-Command cmake -ErrorAction SilentlyContinue
if (-not $cmake) { throw 'CMake was not found. Install CMake and Visual Studio 2022 with Desktop development with C++.' }

$juceDir = $env:JUCE_DIR
if (-not $juceDir) {
    $juceDir = Read-Host 'Enter the JUCE CMake folder (example: C:\JUCE\extras\Build\CMake)'
}
if (-not (Test-Path (Join-Path $juceDir 'JUCEConfig.cmake'))) {
    throw "JUCEConfig.cmake was not found in '$juceDir'. Set JUCE_DIR to the folder containing JUCEConfig.cmake."
}

cmake -S $ProjectDir -B $BuildDir -DJUCE_DIR="$juceDir" -A x64
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed.' }
cmake --build $BuildDir --config Release
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Review the compiler output above.' }

$plugin = Join-Path $BuildDir 'SwiftMeloraAIStudio_artefacts\Release\VST3\Swift Melora AI Studio.vst3'
if (-not (Test-Path $plugin)) {
    $plugin = Get-ChildItem -Path $BuildDir -Filter '*.vst3' -Recurse -Directory -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $plugin) { throw 'Build finished but the VST3 bundle could not be located. Check the build output folder.' }

$dist = Join-Path $ProjectDir 'dist'
New-Item -ItemType Directory -Force -Path $dist | Out-Null
Copy-Item -Path $plugin -Destination $dist -Recurse -Force
Write-Host "VST3 bundle copied to: $dist" -ForegroundColor Green

$iscc = Get-Command ISCC.exe -ErrorAction SilentlyContinue
if (-not $iscc) {
    Write-Warning 'Inno Setup compiler (ISCC.exe) was not found. The VST3 has been built, but no installer EXE was created. Install Inno Setup and run: ISCC.exe Installer\SwiftMeloraAIStudio.iss'
    exit 0
}
& $iscc.Source (Join-Path $ProjectDir 'Installer\SwiftMeloraAIStudio.iss')
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup packaging failed.' }
Write-Host 'Build/package step completed. See the Output folder for the installer.' -ForegroundColor Green
