#define MyAppName "Swift Melora AI Studio"
#define MyAppVersion "0.1.0-prototype"
#define MyPublisher "Swift Melora"
#define MyVST3Source "..\dist\Swift Melora AI Studio.vst3"

[Setup]
AppId={{B2C2C4B1-7A4E-4B62-9C45-81F5B3C7D601}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyPublisher}
DefaultDirName={autopf64}\Swift Melora AI Studio
DisableProgramGroupPage=yes
OutputDir=..\Output
OutputBaseFilename=SwiftMeloraAIStudio-Setup-x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
Uninstallable=yes
WizardStyle=modern
Compression=lzma2
SolidCompression=yes

[Dirs]
Name: "{commoncf64}\VST3"; Flags: uninsneveruninstall

[Files]
Source: "{#MyVST3Source}\*"; DestDir: "{commoncf64}\VST3\Swift Melora AI Studio.vst3"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\Swift Melora AI Studio\Build and compatibility notes"; Filename: "{app}\README.txt"

[Run]
Filename: "{cmd}"; Parameters: "/c echo Swift Melora AI Studio VST3 installed. Restart your DAW and rescan plugins."; Flags: postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{commoncf64}\VST3\Swift Melora AI Studio.vst3"
