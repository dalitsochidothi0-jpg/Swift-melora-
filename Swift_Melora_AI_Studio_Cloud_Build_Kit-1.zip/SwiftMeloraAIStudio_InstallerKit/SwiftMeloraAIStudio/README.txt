SWIFT MELORA AI STUDIO — STARTER PROTOTYPE
==========================================

What this is
------------
A source-code starter for a JUCE audio plugin. It includes a basic high-pass filter,
compressor, processing amount, output trim, a simple interface, and a VST3/Standalone
build target. It is NOT yet a complete AI mixing/mastering engine and has not been
compiled or tested on your computer.

Compatibility
-------------
- Intended build target: Windows 10 64-bit, VST3 and Standalone.
- FL Studio 21 should support VST3.
- Cubase 5 does not support VST3. A separate legacy VST2 build/bridge would be needed;
  that requires checking the installed Cubase 5 bitness and applicable Steinberg SDK terms.
- If Cubase 5 is 32-bit, a 64-bit plugin will not load inside it.

Build requirements
------------------
1. Install Visual Studio 2022 with the Desktop development with C++ workload.
2. Install CMake.
3. Download JUCE from the official JUCE website and install/extract it.
4. Open a Developer PowerShell and configure this project, replacing JUCE_DIR with your
   JUCE CMake directory:

   cmake -S . -B build -DJUCE_DIR="C:/JUCE/extras/Build/CMake"
   cmake --build build --config Release

The exact JUCE_DIR may differ depending on where JUCE was installed. Build output and
installation locations depend on the JUCE version and build configuration.

Important use notes
-------------------
- Keep the plugin bypassed or set its amount low when first testing it.
- Compare processed and bypassed audio at similar loudness; louder can seem better even
  when it is not.
- Check the DAW master meter and leave headroom. This prototype is not a true peak limiter
  and does not guarantee streaming loudness or professional results.
- Always keep an untouched copy of the original recording.

Planned next stages
-------------------
1. Compile and test the basic plugin.
2. Add proper true-peak limiting, loudness metering, presets, and safe output management.
3. Add optional vocal-cleaning and source-separation components.
4. Add project/track workflow support for separate stems and multitrack sessions.
5. Evaluate a separate legacy build path for Cubase 5 if feasible.

JUCE documentation: https://juce.com/learn/documentation/
JUCE downloads: https://juce.com/download/
