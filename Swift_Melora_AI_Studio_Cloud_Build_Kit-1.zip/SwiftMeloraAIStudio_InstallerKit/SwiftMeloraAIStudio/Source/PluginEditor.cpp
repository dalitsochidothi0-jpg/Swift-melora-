#include "PluginEditor.h"

SwiftMeloraAIStudioAudioProcessorEditor::SwiftMeloraAIStudioAudioProcessorEditor (SwiftMeloraAIStudioAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setSize (480, 300);
    autoButton.setButtonText ("ONE-CLICK PROCESSING");
    addAndMakeVisible (autoButton);
    autoAttachment = std::make_unique<ButtonAttachment> (audioProcessor.parameters, "autoOn", autoButton);
    amountSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    amountSlider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 90, 22);
    addAndMakeVisible (amountSlider);
    amountAttachment = std::make_unique<SliderAttachment> (audioProcessor.parameters, "amount", amountSlider);
    outputSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    outputSlider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 90, 22);
    addAndMakeVisible (outputSlider);
    outputAttachment = std::make_unique<SliderAttachment> (audioProcessor.parameters, "output", outputSlider);
    amountLabel.setText ("Processing Amount", juce::dontSendNotification);
    outputLabel.setText ("Output Trim (dB)", juce::dontSendNotification);
    noteLabel.setText ("Starter edition • Compare with bypass • Avoid clipping", juce::dontSendNotification);
    addAndMakeVisible (amountLabel); addAndMakeVisible (outputLabel); addAndMakeVisible (noteLabel);
    amountLabel.setJustificationType (juce::Justification::centred);
    outputLabel.setJustificationType (juce::Justification::centred);
    noteLabel.setJustificationType (juce::Justification::centred);
}

void SwiftMeloraAIStudioAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff101827));
    g.setColour (juce::Colour (0xffffa52f));
    g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawFittedText ("SWIFT MELORA AI STUDIO", 16, 12, getWidth() - 32, 34, juce::Justification::centred, 1);
    g.setColour (juce::Colour (0xffb5e36b));
    g.setFont (14.0f);
    g.drawFittedText ("Automatic audio processing prototype", 16, 44, getWidth() - 32, 22, juce::Justification::centred, 1);
}

void SwiftMeloraAIStudioAudioProcessorEditor::resized()
{
    autoButton.setBounds (100, 78, 280, 34);
    amountSlider.setBounds (90, 120, 120, 112);
    outputSlider.setBounds (270, 120, 120, 112);
    amountLabel.setBounds (70, 228, 160, 22);
    outputLabel.setBounds (250, 228, 160, 22);
    noteLabel.setBounds (12, 263, getWidth() - 24, 22);
}
