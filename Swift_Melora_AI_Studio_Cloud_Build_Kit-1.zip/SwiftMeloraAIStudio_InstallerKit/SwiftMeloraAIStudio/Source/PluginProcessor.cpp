#include "PluginProcessor.h"
#include "PluginEditor.h"

SwiftMeloraAIStudioAudioProcessor::SwiftMeloraAIStudioAudioProcessor()
    : AudioProcessor (BusesProperties()
        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "PARAMETERS", createParameterLayout())
{}

juce::AudioProcessorValueTreeState::ParameterLayout SwiftMeloraAIStudioAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<juce::AudioParameterBool> ("autoOn", "One-Click Processing", true));
    p.push_back (std::make_unique<juce::AudioParameterFloat> ("amount", "Processing Amount",
        juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 55.0f));
    p.push_back (std::make_unique<juce::AudioParameterFloat> ("output", "Output Trim",
        juce::NormalisableRange<float> (-12.0f, 6.0f, 0.1f), 0.0f, "dB"));
    return { p.begin(), p.end() };
}

void SwiftMeloraAIStudioAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
        (juce::uint32) getTotalNumOutputChannels() };
    highPass.prepare (spec);
    compressor.prepare (spec);
    outputGain.prepare (spec);
    highPass.reset(); compressor.reset(); outputGain.reset();
    *highPass.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass (sampleRate, 25.0f);
    compressor.setThreshold (-18.0f);
    compressor.setRatio (2.0f);
    compressor.setAttack (20.0f);
    compressor.setRelease (140.0f);
}

void SwiftMeloraAIStudioAudioProcessor::releaseResources() {}

bool SwiftMeloraAIStudioAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    return in == out && (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo());
}

void SwiftMeloraAIStudioAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const auto enabled = parameters.getRawParameterValue ("autoOn")->load() > 0.5f;
    const auto amount = parameters.getRawParameterValue ("amount")->load() / 100.0f;
    const auto trimDb = parameters.getRawParameterValue ("output")->load();
    if (! enabled) return;

    juce::dsp::AudioBlock<float> block (buffer);
    juce::dsp::ProcessContextReplacing<float> context (block);
    // Amount scales the compression ratio from gentle to moderately firm.
    compressor.setRatio (1.0f + 2.5f * amount);
    compressor.setThreshold (-12.0f - 10.0f * amount);
    highPass.process (context);
    compressor.process (context);
    outputGain.setGainDecibels (trimDb + (1.0f * amount));
    outputGain.process (context);
}

juce::AudioProcessorEditor* SwiftMeloraAIStudioAudioProcessor::createEditor()
{ return new SwiftMeloraAIStudioAudioProcessorEditor (*this); }

void SwiftMeloraAIStudioAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void SwiftMeloraAIStudioAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName (parameters.state.getType()))
        parameters.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{ return new SwiftMeloraAIStudioAudioProcessor(); }
