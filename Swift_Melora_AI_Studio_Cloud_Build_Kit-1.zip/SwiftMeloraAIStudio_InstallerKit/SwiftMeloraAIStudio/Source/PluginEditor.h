#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class SwiftMeloraAIStudioAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit SwiftMeloraAIStudioAudioProcessorEditor (SwiftMeloraAIStudioAudioProcessor&);
    ~SwiftMeloraAIStudioAudioProcessorEditor() override = default;
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    SwiftMeloraAIStudioAudioProcessor& audioProcessor;
    juce::ToggleButton autoButton { "ONE-CLICK PROCESSING" };
    juce::Slider amountSlider, outputSlider;
    juce::Label amountLabel, outputLabel, noteLabel;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    std::unique_ptr<ButtonAttachment> autoAttachment;
    std::unique_ptr<SliderAttachment> amountAttachment, outputAttachment;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SwiftMeloraAIStudioAudioProcessorEditor)
};
